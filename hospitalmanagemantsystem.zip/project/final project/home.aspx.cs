﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Xml.Linq;

public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {
        Response.Redirect("aboutus.aspx");
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["FINALConnectionString"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into APPOINT values(@NAME,@EMAIL,@DATE,@CITY)", con);
        cmd.Parameters.AddWithValue("NAME", TextBox1.Text);
            cmd.Parameters.AddWithValue("EMAIL",TextBox2.Text);
        cmd.Parameters.AddWithValue("DATE",TextBox3.Text);
        cmd.Parameters.AddWithValue("CITY",TextBox4.Text);
        cmd.ExecuteNonQuery();
        con.Close();
    }
    protected void Button16_Click(object sender, EventArgs e)
    {
        Response.Redirect("registation form.aspx");

    }
}