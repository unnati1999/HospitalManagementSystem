﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class main : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Aboutus.aspx");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Redirect("aboutus.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("CONTACTUS.aspx");
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        Response.Redirect("DOCTOR1.aspx");
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        Response.Redirect("doctor3.aspx");
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        Response.Redirect("doctor2.aspx");
    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        Response.Redirect("DOCTOR1.aspx");
    }
    protected void Button13_Click(object sender, EventArgs e)
    {
        Response.Redirect("doctor search.aspx");
    }
    protected void Button14_Click(object sender, EventArgs e)
    {
        Response.Redirect("gallery.aspx");
    }
    protected void Button15_Click(object sender, EventArgs e)
    {
        Response.Redirect("signup.aspx");
    }
}
