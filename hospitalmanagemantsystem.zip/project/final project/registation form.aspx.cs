﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Configuration;

public partial class registation_form : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button16_Click(object sender, EventArgs e)
    {
        string gender = String.Empty;
        if (rbfemale.Checked)
        {
            gender = "female";
        }
        else if (rbmale.Checked)
        {
            gender = "male";
        }
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["fregistationConnectionString"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into fregistation values(@Name,@email,@Password,@Confirmpassword,@Fathername,@Contactnumber,@City,@Pincode,@Gender,@Bloodgroup)", con);
        cmd.Parameters.AddWithValue("Name", TextBox1.Text);
        cmd.Parameters.AddWithValue("email", TextBox2.Text);
        cmd.Parameters.AddWithValue("Password", TextBox3.Text);
        cmd.Parameters.AddWithValue("Confirmpassword", TextBox4.Text);
        cmd.Parameters.AddWithValue("Fathername", TextBox5.Text);
        cmd.Parameters.AddWithValue("Contactnumber", TextBox6.Text);
        cmd.Parameters.AddWithValue("City", TextBox7.Text);
        cmd.Parameters.AddWithValue("Pincode", TextBox8.Text);
        cmd.Parameters.AddWithValue("Gender", gender);
        cmd.Parameters.AddWithValue("Bloodgroup", TextBox9.Text);
        cmd.ExecuteNonQuery();
        con.Close();
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
}